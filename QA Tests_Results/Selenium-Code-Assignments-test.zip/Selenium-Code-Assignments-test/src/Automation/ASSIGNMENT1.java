package Automation;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class ASSIGNMENT1 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private String User = "YourUser"; //Change the Usuer 
  private String Password = "YourPassword"; // Change the Password

  @Before
  public void setUp() throws Exception {
	//My test Run on google Chrome you need the put de file path of the drive for run this test 
	System.setProperty("webdriver.chrome.driver", "C:/ChromeDriver/chromedriver.exe");
	driver = new ChromeDriver();
    baseUrl = "https://www.facebook.com/"; //url base
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testFacebook() throws Exception {
    driver.get(baseUrl + "/");
    driver.findElement(By.id("email")).sendKeys(User); //user 
    driver.findElement(By.id("pass")).sendKeys(Password); // password 
    driver.findElement(By.id("loginbutton")).click();
    //verify  login 
    assertTrue(isElementPresent(By.cssSelector("#navItem_217974574879787 > a._5afe > div.linkWrap.noCount")));
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    //Print Hello Word 
    System.out.println("Hello Word");
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
