package Automation;

import java.util.regex.Pattern;
import java.awt.Desktop.Action;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Mouse;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.support.ui.Select;

import com.sun.jna.platform.win32.Guid.GUID.ByReference;

public class ASSIGNMENT2 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  private String User ="renato.m.milagres@gmail.com"; //My user created
  private String key ="Abcd123*"; //Password
  //Xpaths of 5 stars
  String star1="//div[@class='wh-rating-choices-holder']/a[contains(@href, '#')][1]";
  String star2="//div[@class='wh-rating-choices-holder']/a[contains(@href, '#')][2]";
  String star3="//div[@class='wh-rating-choices-holder']/a[contains(@href, '#')][3]";
  String star4="//div[@class='wh-rating-choices-holder']/a[contains(@href, '#')][4]";
  String star5="//div[@class='wh-rating-choices-holder']/a[contains(@href, '#')][5]";
  
  

  @Before
  public void setUp() throws Exception {
	//My test Run on google Chrome you need the put de file path of the drive for run this test 
	    System.setProperty("webdriver.chrome.driver", "C:/ChromeDriver/chromedriver.exe");
		driver = new ChromeDriver();
	    baseUrl = "https://wallethub.com";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 
	     
       
  }

  @Test
  //The test will test the click on the fourth star (1)
 // hover over the stars and click on the fourth star. 
  public void testStars() throws Exception {
	
    driver.get(baseUrl + "/profile/test_insurance_company/");
    //Find the elements star in the HTML using the XPATH 
    WebElement srating1=driver.findElement(By.xpath(star1));            
    WebElement srating2=driver.findElement(By.xpath(star2));            
    WebElement srating3=driver.findElement(By.xpath(star3));            
    WebElement srating4=driver.findElement(By.xpath(star4));            
    WebElement srating5=driver.findElement(By.xpath(star5));    
    WebElement stars = driver.findElement(By.className("wh-rating-notes")); // over element
    //test stars 
    Thread.sleep(9000); 
    // I use the thread because my test was developed using vpn 
    //so was necessary used "thread" because sometimes the conexion was bad
    // Thhread.sleep using for waiting the loading the page
    
    driver.findElement(By.className("af-icon-cross")).click();
    Thread.sleep(1000);  // Thhread.sleep using for waiting the loading the page
    Actions builder = new Actions(driver);  
    builder.moveToElement(stars).build().perform();
    builder.moveToElement(srating1).build().perform();
    Thread.sleep(10);  // Thhread.sleep using for waiting the loading the page
    builder.moveToElement(srating2).build().perform();
    Thread.sleep(10);  // Thhread.sleep using for waiting the loading the page
    builder.moveToElement(srating3).build().perform();
    Thread.sleep(10);  // Thhread.sleep using for waiting the loading the page
    builder.moveToElement(srating4).build().perform();
    Thread.sleep(10);  // Thhread.sleep using for waiting the loading the page
    builder.moveToElement(srating5).build().perform();
    srating4.click();  // Clik in fourth star
        }
  
    @Test // this test verify if the star was selection
    // make sure the stars inside get lit up when you hover over them
    public void TestRatingStars() throws Exception {
    	 //Find the elements star in the HTML using the XPATH 
    	driver.get(baseUrl + "/profile/test_insurance_company/");
        WebElement srating1=driver.findElement(By.xpath(star1));            
        WebElement srating2=driver.findElement(By.xpath(star2));            
        WebElement srating3=driver.findElement(By.xpath(star3));            
        WebElement srating4=driver.findElement(By.xpath(star4));            
        WebElement srating5=driver.findElement(By.xpath(star5));    
        WebElement stars = driver.findElement(By.className("wh-rating-notes")); // over element
//   
        Thread.sleep(9000);
        // I use the thread because my test was developed using vpn 
        //so was necessary used "thread" because sometimes the conexion was bad
        // Thhread.sleep using for waiting the loading the page
        //test stars 
        driver.findElement(By.className("af-icon-cross")).click();
       Thread.sleep(1000);
        Actions builder = new Actions(driver);  
        builder.moveToElement(stars).build().perform();
        
        builder.moveToElement(srating1).build().perform();
        Thread.sleep(10);
        try {// if selection is ok , I can find the rating status , and I used this	
        	//for confirmation the selection
      	  assertEquals("Bad", driver.findElement(By.cssSelector("em > span")).getText());
      	} catch (Error e) {
      	  verificationErrors.append(e.toString());
      	}
        builder.moveToElement(srating2).build().perform();
        Thread.sleep(10);
        try {
     	  assertEquals("Below Average", driver.findElement(By.cssSelector("em > span")).getText());
      	} catch (Error e) {
      	  verificationErrors.append(e.toString());
      	}
        builder.moveToElement(srating3).build().perform();
        Thread.sleep(10);
        try {
      	  assertEquals("Average", driver.findElement(By.cssSelector("em > span")).getText());
      	} catch (Error e) {
      	  verificationErrors.append(e.toString());
      	}
        builder.moveToElement(srating4).build().perform();
        Thread.sleep(10);
        try {
      	  assertEquals("Good", driver.findElement(By.cssSelector("em > span")).getText());
      	} catch (Error e) {
      	  verificationErrors.append(e.toString());
      	}
        builder.moveToElement(srating5).build().perform();
        try {
        	  assertEquals("Excellent", driver.findElement(By.cssSelector("em > span")).getText());
       	} catch (Error e) {
        	  verificationErrors.append(e.toString());
        	}
        srating5.click();	
    }
        @Test //click on the fifth star and submit a Review; 
        
            public void TestSubimitRating() throws Exception {
        	//Is necessary made a login before a submit a rating
        	//Login was with my user, you can change the user in the variables initials
        	driver.get(baseUrl + "/reviews/?review_action=write&iid=13732055&ro=1&rating=3");
            driver.findElement(By.cssSelector("a.login")).click();
            driver.findElement(By.name("em")).clear();
            driver.findElement(By.name("em")).sendKeys(User); //Parameter User
            driver.findElement(By.name("pw")).clear();
            driver.findElement(By.name("pw")).sendKeys(key);//Password User
            driver.findElement(By.xpath("(//button[@type='button'])[2]")).click();
            Thread.sleep(9000);
            driver.get(baseUrl + "/profile/test_insurance_company/");
          //Find the elements star in the HTML using the XPATH 
            WebElement srating1=driver.findElement(By.xpath(star1));            
            WebElement srating2=driver.findElement(By.xpath(star2));            
            WebElement srating3=driver.findElement(By.xpath(star3));            
            WebElement srating4=driver.findElement(By.xpath(star4));            
            WebElement srating5=driver.findElement(By.xpath(star5));    
            WebElement stars = driver.findElement(By.className("wh-rating-notes")); // over element
            //test stars 
            Thread.sleep(9000);
            // I use the thread because my test was developed using vpn 
            //so was necessary used "thread" because sometimes the conexion was bad
            // Thhread.sleep using for waiting the loading the page
            //test stars 
            driver.findElement(By.className("af-icon-cross")).click();
            Thread.sleep(1000);
            Actions builder = new Actions(driver); 
            builder.moveToElement(stars).build().perform();
            builder.moveToElement(srating5).build().perform();
            srating5.click(); //Click in 5 star
            driver.findElement(By.cssSelector("i.bf-icon-down-open")).click();
            driver.findElement(By.linkText("Health")).click(); 
            //On the page you get redirected to, click on the Policy dropdown and change the value to �Health� 
            Thread.sleep(9000);
            driver.findElement(By.xpath("//a[contains(.,'5')]")).click(); //COnfirm the 5 star are clicked
            driver.findElement(By.id("review-content")).clear();
            driver.findElement(By.id("review-content")).sendKeys("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus tristique consequat ullamcorper. Integer sed aliquet tortor. Cras commodo nec purus vel pulvinar. Vivamus aliquet ante vitae nulla tincidunt sagittis. Donec in erat interdum, dapibus lacus vitae, ultrices urna. Aliquam vitae elit vel lorem mollis tincidunt quis sed tortor. Suspendisse interdum tortor sed nulla sodales, sit amet rhoncus augue mollis. In posuere ipsum eget ex dapibus fermentum. Suspendisse eget mollis lacus. Nullam fringilla porta elit. Sed a interdum justo. Praesent eu ex quis enim eleifend cursus at pulvinar purus. Cras luctus mollis maximus. Donec luctus, quam sed congue molestie, erat risus dapibus nisl, vel mollis metus nunc vel arcu. Quisque semper ex non enim porta, in bibendum ligula tempus.");
           // Click on the link �Write a review� and write some random text (minimum of 200 characters). 
            Thread.sleep(9000); //waiting because my VPN =( SORRY FOR THIS GUYS =( 
            driver.findElement(By.cssSelector("input.btn.blue")).click(); //Click on submit 
            driver.findElement(By.cssSelector("h1 > span")).click();
            try { //Test verify the submit
              assertEquals("Your Test Insurance Company review has been posted.", driver.findElement(By.cssSelector("h1 > span")).getText());
            } catch (Error e) {
              verificationErrors.append(e.toString());
            }
            driver.get("https://wallethub.com/profile/renato_m_milagres/reviews/");
            //Go to https://wallethub.com/profile/<username>/reviews/ and assertTrue() that you can see the review feed with the text you entered on the previous page.  
            assertEquals("Test Insurance Company", driver.findElement(By.cssSelector("div.profile.profile-company-name > a > strong")).getText());
            
        }

    	
 @After
  public void tearDown() throws Exception {
    driver.quit(); //end the test quit the browser
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
  //method create for hover elements
  public static void Hover(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
	}
  //method create for hover and click elements
  public static void HoverAndClick(WebDriver driver,WebElement elementToHover,WebElement elementToClick) {
		Actions action = new Actions(driver);
		action.moveToElement(elementToHover).click(elementToClick).build().perform();
	}
  

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
